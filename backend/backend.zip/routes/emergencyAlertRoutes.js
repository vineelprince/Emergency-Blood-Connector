import express from "express";

import {
  createEmergencyAlert,
  getEmergencyAlerts,
} from "../controllers/emergencyAlertController.js";

import { verifyToken } from "../middleware/authMiddleware.js";

const router = express.Router();

// ================= CREATE ALERT =================

router.post(
  "/",
  verifyToken,
  createEmergencyAlert
);

// ================= GET ALERTS =================

router.get(
  "/",
  verifyToken,
  getEmergencyAlerts
);

export default router;