import { EmergencyAlertModel } from "../models/emergencyAlert.js";

import { io } from "../server.js";

// ================= CREATE ALERT =================

export const createEmergencyAlert =
  async (req, res) => {
    try {

      const {
        bloodGroup,
        location,
        message,
      } = req.body;

      const alert =
        await EmergencyAlertModel.create({
          bloodGroup,
          location,
          message,
          requester: req.user.id,
        });

      // ================= REALTIME EMIT =================
      console.log("EMITTING ALERT");
      console.log(alert);

      io.emit(
        "newEmergencyAlert",
        alert
      );

      return res.status(201).json({
        success: true,
        message:
          "Emergency alert created successfully",
        alert,
      });

    } catch (error) {

      console.log(error);

      return res.status(500).json({
        success: false,
        message: error.message,
      });

    }
  };

// ================= GET ALERTS =================

export const getEmergencyAlerts =
  async (req, res) => {
    try {

      const alerts =
        await EmergencyAlertModel.find()
          .populate(
            "requester",
            "firstName lastName email"
          )
          .sort({ createdAt: -1 });

      return res.status(200).json({
        success: true,
        totalAlerts: alerts.length,
        alerts,
      });

    } catch (error) {

      console.log(error);

      return res.status(500).json({
        success: false,
        message: error.message,
      });

    }
  };