function Loader() {
  return (
    <div className="flex items-center justify-center py-20">

      <div className="flex flex-col items-center">

        {/* SPINNER */}
        <div className="w-16 h-16 border-4 border-red-200 border-t-red-600 rounded-full animate-spin"></div>

        {/* TEXT */}
        <p className="mt-4 text-lg font-semibold text-gray-600">
          Loading...
        </p>

      </div>

    </div>
  );
}

export default Loader;