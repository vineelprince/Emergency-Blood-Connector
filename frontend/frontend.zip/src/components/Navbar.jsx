import { Link, useNavigate } from "react-router-dom";

function Navbar() {

  const navigate =
    useNavigate();

  const user =
    JSON.parse(
      localStorage.getItem("user")
    );

  const handleLogout =
    () => {

      localStorage.removeItem("token");
      localStorage.removeItem("user");

      navigate("/login");
    };

  return (

    <nav className="sticky top-0 z-50 bg-white shadow-sm">

      <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">

        <Link
          to="/"
          className="text-3xl font-bold text-red-600"
        >
          BloodConnect
        </Link>

        <div className="hidden md:flex items-center gap-8">

          <Link to="/">
            Home
          </Link>

          <Link to="/emergency-search">
            Find Blood
          </Link>

          <Link to="/hospitals">
            Hospitals
          </Link>

          <Link to="/emergency-map">
            Emergency Map
          </Link>

          {user && (
            <Link to="/dashboard">
              Dashboard
            </Link>
          )}

        </div>

        <div className="flex items-center gap-4">

          {!user ? (
            <>
              <Link
                to="/login"
                className="font-medium"
              >
                Login
              </Link>

              <Link
                to="/register"
                className="bg-red-600 text-white px-5 py-2 rounded-lg"
              >
                Register
              </Link>
            </>
          ) : (
            <button
              onClick={handleLogout}
              className="bg-red-600 text-white px-5 py-2 rounded-lg"
            >
              Logout
            </button>
          )}

        </div>

      </div>

    </nav>
  );
}

export default Navbar;