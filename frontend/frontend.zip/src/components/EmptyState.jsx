function EmptyState({
  title,
  description,
  icon,
}) {
  return (
    <div className="bg-white rounded-2xl shadow-md p-10 text-center">

      {/* ICON */}
      <div className="text-6xl mb-4">
        {icon}
      </div>

      {/* TITLE */}
      <h2 className="text-2xl font-bold text-gray-700 mb-3">
        {title}
      </h2>

      {/* DESCRIPTION */}
      <p className="text-gray-500">
        {description}
      </p>

    </div>
  );
}

export default EmptyState;