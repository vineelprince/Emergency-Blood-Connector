import { Link } from "react-router-dom";

function HeroSection() {
  return (
    <section className="bg-gradient-to-r from-red-700 to-red-600 text-white">
      <div className="max-w-7xl mx-auto px-6 py-24">

        <div className="grid lg:grid-cols-2 gap-12 items-center">

          <div>
            <span className="bg-white/20 px-4 py-2 rounded-full text-sm">
              Emergency Blood Response Platform
            </span>

            <h1 className="text-5xl lg:text-7xl font-bold mt-6 leading-tight">
              Connecting Blood Donors With Lives In Need
            </h1>

            <p className="text-xl mt-6 text-red-100">
              Search donors, hospitals and blood banks instantly during emergencies.
            </p>

            <div className="flex gap-4 mt-8">
              <Link
                to="/register"
                className="bg-white text-red-600 px-8 py-4 rounded-xl font-bold"
              >
                Become Donor
              </Link>

              <Link
                to="/login"
                className="border border-white px-8 py-4 rounded-xl font-bold"
              >
                Login
              </Link>
            </div>
          </div>

          <div className="hidden lg:block">
            <img
              src="https://images.unsplash.com/photo-1584515933487-779824d29309"
              alt="Blood Donation"
              className="rounded-3xl shadow-2xl"
            />
          </div>

        </div>
      </div>
    </section>
  );
}

export default HeroSection;