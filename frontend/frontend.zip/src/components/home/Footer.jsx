function Footer() {
  return (
    <footer className="bg-gray-900 text-white">

      <div className="max-w-7xl mx-auto px-6 py-16">

        <h2 className="text-3xl font-bold text-red-500">
          BloodConnect
        </h2>

        <p className="mt-4 text-gray-400 max-w-xl">
          Connecting donors, hospitals and blood banks through a unified emergency response network.
        </p>

        <div className="border-t border-gray-800 mt-10 pt-6 text-gray-500">
          © 2026 BloodConnect. All Rights Reserved.
        </div>

      </div>

    </footer>
  );
}

export default Footer;