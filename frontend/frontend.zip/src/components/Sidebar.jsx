import {
  Link,
  useLocation,
  useNavigate,
} from "react-router-dom";

import { useState } from "react";

function Sidebar({ closeSidebar }) {
  const location = useLocation();

  const navigate = useNavigate();

  const [search, setSearch] = useState("");

  // ================= LOGOUT =================

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");

    navigate("/login");
  };

  // ================= ACTIVE LINK =================

  const activeClass = (path) =>
    location.pathname === path
      ? "bg-red-600 text-white"
      : "text-gray-700 hover:bg-red-100";

  // ================= MENU ITEMS =================

  const menuItems = [
    {
      name: "Dashboard",
      path: "/dashboard",
      icon: "🏠",
    },
    {
      name: "Search Donors",
      path: "/donors",
      icon: "🔍",
    },
    {
      name: "Hospitals",
      path: "/hospitals",
      icon: "🏨",
    },
    {
      name: "Emergency Search",
      path: "/emergency-search",
      icon: "🚨",
    },
    {
      name: "Create Request",
      path: "/create-request",
      icon: "🚨",
    },
    {
  name: "Emergency Map",
  path: "/emergency-map",
  icon: "🌍",
},
    {
      name: "All Requests",
      path: "/requests",
      icon: "📋",
    },
    {
      name: "My Requests",
      path: "/my-requests",
      icon: "🩸",
    },
    {
      name: "Analytics",
      path: "/analytics",
      icon: "📊",
    },
    {
      name: "My Profile",
      path: "/profile",
      icon: "👤",
    },
  ];

  // ================= FILTERED MENU =================

  const filteredItems = menuItems.filter(
    (item) =>
      item.name
        .toLowerCase()
        .includes(search.toLowerCase())
  );

  return (
    <div className="w-72 min-h-screen bg-white shadow-lg p-6">

      {/* LOGO */}
      <div className="mb-8">

        <h1 className="text-3xl font-bold text-red-600">
          BloodConnect 🚨
        </h1>

      </div>

      {/* SEARCH */}
      <input
        type="text"
        placeholder="Search menu..."
        value={search}
        onChange={(e) =>
          setSearch(e.target.value)
        }
        className="w-full border border-gray-300 rounded-xl px-4 py-3 mb-6 outline-none focus:ring-2 focus:ring-red-400"
      />

      {/* NAVIGATION */}
      <div className="flex flex-col gap-3">

        {filteredItems.map((item) => (

          <Link
            key={item.path}
            to={item.path}
            onClick={closeSidebar}
            className={`px-4 py-3 rounded-xl font-semibold transition ${activeClass(
              item.path
            )}`}
          >
            {item.icon} {item.name}
          </Link>

        ))}

        {/* LOGOUT */}
        <button
          onClick={handleLogout}
          className="mt-10 bg-red-600 text-white py-3 rounded-xl font-semibold hover:bg-red-700 transition"
        >
          Logout
        </button>

      </div>

    </div>
  );
}

export default Sidebar;