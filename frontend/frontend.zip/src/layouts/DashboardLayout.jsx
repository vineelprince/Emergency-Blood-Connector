import { useState } from "react";

import Sidebar from "../components/Sidebar";
import FloatingEmergencyButtons from "../components/FloatingEmergencyButtons";

function DashboardLayout({ children }) {
  const [sidebarOpen, setSidebarOpen] =
    useState(false);

  return (
    <div className="flex min-h-screen bg-red-50">

      {/* MOBILE OVERLAY */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/40 z-40 lg:hidden"
          onClick={() =>
            setSidebarOpen(false)
          }
        />
      )}

      {/* SIDEBAR */}
      <div
        className={`
          fixed lg:static top-0 left-0 z-50
          transform transition-transform duration-300
          ${
            sidebarOpen
              ? "translate-x-0"
              : "-translate-x-full"
          }
          lg:translate-x-0
        `}
      >
        <Sidebar
          closeSidebar={() =>
            setSidebarOpen(false)
          }
        />
      </div>

      {/* MAIN CONTENT */}
      <div className="flex-1">

        {/* MOBILE HEADER */}
        <div className="lg:hidden bg-white shadow-md p-4 flex items-center justify-between">

          <h1 className="text-2xl font-bold text-red-600">
            BloodConnect 🚨
          </h1>

          <button
            onClick={() =>
              setSidebarOpen(true)
            }
            className="text-3xl"
          >
            ☰
          </button>

        </div>

        {/* PAGE CONTENT */}
        <main>{children}</main>
        <FloatingEmergencyButtons />

      </div>

    </div>
  );
}

export default DashboardLayout;