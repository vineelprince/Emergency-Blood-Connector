import { useEffect, useState } from "react";

import axiosInstance from "../../api/axios";

import Loader from "../../components/Loader";

import {
  PieChart,
  Pie,
  Cell,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Legend,
} from "recharts";

function AnalyticsPage() {
  const [loading, setLoading] =
    useState(false);

  const [stats, setStats] = useState({
    totalDonors: 0,
    availableDonors: 0,
    totalRequests: 0,
    myRequests: 0,
  });

  // ================= FETCH STATS =================

  const fetchStats = async () => {
    try {

      setLoading(true);

      const token =
        localStorage.getItem("token");

      const response =
        await axiosInstance.get(
          "/dashboard/stats",
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );

      setStats(response.data.stats);

    } catch (error) {

      console.log(error);

    } finally {

      setLoading(false);

    }
  };

  // ================= USE EFFECT =================

  useEffect(() => {
    fetchStats();
  }, []);

  // ================= PIE DATA =================

  const donorData = [
    {
      name: "Available",
      value: stats.availableDonors,
    },
    {
      name: "Unavailable",
      value:
        stats.totalDonors -
        stats.availableDonors,
    },
  ];

  // ================= BAR DATA =================

  const systemData = [
    {
      name: "Donors",
      total: stats.totalDonors,
    },
    {
      name: "Requests",
      total: stats.totalRequests,
    },
    {
      name: "My Requests",
      total: stats.myRequests,
    },
  ];

  // chart colors
  const COLORS = [
    "#dc2626",
    "#fca5a5",
  ];

  return (
    <div className="min-h-screen bg-red-50 p-6">

      <div className="max-w-7xl mx-auto">

        {/* HEADER */}
        <div className="mb-8">

          <h1 className="text-4xl font-bold text-red-600 mb-2">
            System Analytics 📊
          </h1>

          <p className="text-gray-600">
            Monitor blood donation ecosystem performance.
          </p>

        </div>

        {/* LOADING */}
        {loading ? (
          <Loader />
        ) : (
          <>

            {/* STATS CARDS */}
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">

              {/* TOTAL DONORS */}
              <div className="bg-white rounded-2xl shadow-md p-6">

                <h2 className="text-lg font-semibold text-gray-700 mb-2">
                  Total Donors
                </h2>

                <p className="text-4xl font-bold text-red-600">
                  {stats.totalDonors}
                </p>

              </div>

              {/* AVAILABLE DONORS */}
              <div className="bg-white rounded-2xl shadow-md p-6">

                <h2 className="text-lg font-semibold text-gray-700 mb-2">
                  Available Donors
                </h2>

                <p className="text-4xl font-bold text-green-600">
                  {stats.availableDonors}
                </p>

              </div>

              {/* TOTAL REQUESTS */}
              <div className="bg-white rounded-2xl shadow-md p-6">

                <h2 className="text-lg font-semibold text-gray-700 mb-2">
                  Total Requests
                </h2>

                <p className="text-4xl font-bold text-blue-600">
                  {stats.totalRequests}
                </p>

              </div>

              {/* MY REQUESTS */}
              <div className="bg-white rounded-2xl shadow-md p-6">

                <h2 className="text-lg font-semibold text-gray-700 mb-2">
                  My Requests
                </h2>

                <p className="text-4xl font-bold text-orange-500">
                  {stats.myRequests}
                </p>

              </div>

            </div>

            {/* CHARTS */}
            <div className="grid lg:grid-cols-2 gap-8">

              {/* PIE CHART */}
              <div className="bg-white rounded-2xl shadow-md p-6">

                <h2 className="text-2xl font-bold text-red-600 mb-6">
                  Donor Availability
                </h2>

                <div className="h-80">

                  <ResponsiveContainer
                    width="100%"
                    height="100%"
                  >

                    <PieChart>

                      <Pie
                        data={donorData}
                        dataKey="value"
                        outerRadius={120}
                        label
                      >

                        {donorData.map(
                          (entry, index) => (
                            <Cell
                              key={index}
                              fill={
                                COLORS[index %
                                  COLORS.length]
                              }
                            />
                          )
                        )}

                      </Pie>

                      <Tooltip />

                    </PieChart>

                  </ResponsiveContainer>

                </div>

              </div>

              {/* BAR CHART */}
              <div className="bg-white rounded-2xl shadow-md p-6">

                <h2 className="text-2xl font-bold text-red-600 mb-6">
                  System Overview
                </h2>

                <div className="h-80">

                  <ResponsiveContainer
                    width="100%"
                    height="100%"
                  >

                    <BarChart data={systemData}>

                      <CartesianGrid
                        strokeDasharray="3 3"
                      />

                      <XAxis dataKey="name" />

                      <YAxis />

                      <Tooltip />

                      <Legend />

                      <Bar
                        dataKey="total"
                        fill="#dc2626"
                      />

                    </BarChart>

                  </ResponsiveContainer>

                </div>

              </div>

            </div>

          </>
        )}

      </div>

    </div>
  );
}

export default AnalyticsPage;