import { useEffect, useState } from "react";
import Loader from "../../components/Loader";
import EmptyState from "../../components/EmptyState";
import axiosInstance from "../../api/axios";
import socket from "../../socket";


function MyRequestsPage() {
  const [requests, setRequests] = useState([]);

  const [loading, setLoading] = useState(true);

  // fetch requests
  const fetchMyRequests = async () => {
    try {
      const token = localStorage.getItem("token");

      const response = await axiosInstance.get(
        "/requests/my-requests",
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      setRequests(response.data.requests);
    } catch (error) {
      console.log(error);

      alert(
        error.response?.data?.message ||
          "Failed to fetch requests"
      );
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {

  fetchMyRequests();

  socket.on(
    "new-request",
    fetchMyRequests
  );

  socket.on(
    "request-response",
    fetchMyRequests
  );

  socket.on(
    "request-status-updated",
    fetchMyRequests
  );

  return () => {

    socket.off(
      "new-request",
      fetchMyRequests
    );

    socket.off(
      "request-response",
      fetchMyRequests
    );

    socket.off(
      "request-status-updated",
      fetchMyRequests
    );
  };

}, []);

  // update request status
  const updateStatus = async (
    requestId,
    status
  ) => {
    try {
      const token = localStorage.getItem("token");

      await axiosInstance.put(
        `/requests/${requestId}`,
        { status },
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      // refresh requests
      fetchMyRequests();

      alert(`Request marked as ${status}`);
    } catch (error) {
      console.log(error);

      alert(
        error.response?.data?.message ||
          "Failed to update request"
      );
    }
  };

  // status color
  const getStatusColor = (status) => {
    switch (status) {
      case "ACCEPTED":
        return "bg-blue-500 text-white";

      case "COMPLETED":
        return "bg-green-600 text-white";

      case "CANCELLED":
        return "bg-gray-500 text-white";

      default:
        return "bg-red-500 text-white";
    }
  };

  return (
    <div className="min-h-screen bg-red-50 p-6">

      <div className="max-w-7xl mx-auto">

        {/* HEADER */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-red-600 mb-2">
            My Emergency Requests 📋
          </h1>

          <p className="text-gray-600">
            Track and manage your emergency requests.
          </p>
        </div>

        {/* LOADING */}
        {loading ? (
          <div className="text-center text-lg text-gray-600">
            <Loader />
          </div>
        ) : requests.length === 0 ? (
          <EmptyState
  icon="🚨"
  title="No Requests Found"
  description="You have not created any emergency requests yet."
/>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">

            {requests.map((request) => (
              <div
  key={request._id}
  className="bg-white rounded-2xl shadow-md p-6"
>

  <div className="flex justify-between items-center mb-4">

    <span
      className={`px-3 py-1 rounded-full text-sm font-semibold ${getStatusColor(
        request.status
      )}`}
    >
      {request.status}
    </span>

    <span className="bg-red-100 text-red-600 px-3 py-1 rounded-full text-sm font-semibold">
      {request.responders?.length || 0} Responses
    </span>

  </div>

  <h2 className="text-2xl font-bold text-red-600 mb-4">
    {request.patientName}
  </h2>

  <div className="space-y-2 text-gray-700">

    <p>
      Blood Group:
      <strong> {request.bloodGroup}</strong>
    </p>

    <p>
      Hospital:
      <strong> {request.hospitalName}</strong>
    </p>

    <p>
      Address:
      <strong> {request.hospitalAddress}</strong>
    </p>

    <p>
      Contact:
      <strong> {request.contactNumber}</strong>
    </p>

  </div>

  {request.responders?.length > 0 && (

    <div className="mt-6 border-t pt-4">

      <h3 className="font-bold mb-3">
        Responders
      </h3>

      <div className="space-y-3">

        {request.responders.map(
          (responder) => (

            <div
              key={responder._id}
              className="bg-gray-50 rounded-xl p-3"
            >

              <p className="font-semibold">
                {responder.donor?.firstName}
                {" "}
                {responder.donor?.lastName}
              </p>

              <p>
                {responder.donor?.bloodGroup}
              </p>

              <div className="flex gap-2 mt-2">

                <a
                  href={`tel:${responder.donor?.contact?.phoneNumber}`}
                  className="bg-blue-600 text-white px-3 py-1 rounded"
                >
                  Call
                </a>

                <a
                  href={`https://wa.me/${responder.donor?.contact?.phoneNumber}`}
                  target="_blank"
                  rel="noreferrer"
                  className="bg-green-600 text-white px-3 py-1 rounded"
                >
                  WhatsApp
                </a>

              </div>

            </div>
          )
        )}

      </div>

    </div>

  )}

  <div className="mt-6 flex flex-wrap gap-3">

    <button
      onClick={() =>
        updateStatus(
          request._id,
          "ACCEPTED"
        )
      }
      className="bg-blue-500 text-white px-4 py-2 rounded-lg"
    >
      Accept
    </button>

    <button
      onClick={() =>
        updateStatus(
          request._id,
          "COMPLETED"
        )
      }
      className="bg-green-600 text-white px-4 py-2 rounded-lg"
    >
      Fulfilled
    </button>

    <button
      onClick={() =>
        updateStatus(
          request._id,
          "CANCELLED"
        )
      }
      className="bg-gray-500 text-white px-4 py-2 rounded-lg"
    >
      Cancel
    </button>

  </div>

</div>
            ))}

          </div>
        )}

      </div>
    </div>
  );
}

export default MyRequestsPage;