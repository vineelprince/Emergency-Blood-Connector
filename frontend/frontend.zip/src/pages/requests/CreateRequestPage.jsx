import { useState } from "react";

import axiosInstance from "../../api/axios";

function CreateRequestPage() {
  const [formData, setFormData] = useState({
    patientName: "",
    bloodGroup: "",
    unitsRequired: "",
    hospitalName: "",
    hospitalAddress: "",
    contactNumber: "",
    urgency: "HIGH",
    additionalNotes: "",
  });

  const [loading, setLoading] = useState(false);

  // handle change
  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  // handle submit
  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      setLoading(true);

      const token = localStorage.getItem("token");

      const response = await axiosInstance.post(
        "/requests",
        formData,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      console.log(response.data);

      alert("Emergency request created successfully");

      // reset form
      setFormData({
        patientName: "",
        bloodGroup: "",
        unitsRequired: "",
        hospitalName: "",
        hospitalAddress: "",
        contactNumber: "",
        urgency: "HIGH",
        additionalNotes: "",
      });
    } catch (error) {
      console.log(error);

      alert(
        error.response?.data?.message ||
          "Failed to create request"
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-red-50 p-6">

      <div className="max-w-4xl mx-auto">

        {/* HEADER */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-red-600 mb-2">
            Emergency Blood Request 🚨
          </h1>

          <p className="text-gray-600">
            Create urgent blood requests instantly.
          </p>
        </div>

        {/* FORM */}
        <div className="bg-white rounded-2xl shadow-md p-8">

          <form
            onSubmit={handleSubmit}
            className="grid md:grid-cols-2 gap-6"
          >

            {/* PATIENT NAME */}
            <input
              type="text"
              name="patientName"
              placeholder="Patient Name"
              value={formData.patientName}
              onChange={handleChange}
              className="border border-gray-300 rounded-lg px-4 py-3"
            />

            {/* BLOOD GROUP */}
            <select
              name="bloodGroup"
              value={formData.bloodGroup}
              onChange={handleChange}
              className="border border-gray-300 rounded-lg px-4 py-3"
            >
              <option value="">
                Select Blood Group
              </option>

              <option>A+</option>
              <option>A-</option>
              <option>B+</option>
              <option>B-</option>
              <option>AB+</option>
              <option>AB-</option>
              <option>O+</option>
              <option>O-</option>
            </select>

            {/* UNITS */}
            <input
              type="number"
              name="unitsRequired"
              placeholder="Units Required"
              value={formData.unitsRequired}
              onChange={handleChange}
              className="border border-gray-300 rounded-lg px-4 py-3"
            />

            {/* CONTACT */}
            <input
              type="text"
              name="contactNumber"
              placeholder="Contact Number"
              value={formData.contactNumber}
              onChange={handleChange}
              className="border border-gray-300 rounded-lg px-4 py-3"
            />

            {/* HOSPITAL */}
            <input
              type="text"
              name="hospitalName"
              placeholder="Hospital Name"
              value={formData.hospitalName}
              onChange={handleChange}
              className="border border-gray-300 rounded-lg px-4 py-3"
            />

            {/* ADDRESS */}
            <input
              type="text"
              name="hospitalAddress"
              placeholder="Hospital Address"
              value={formData.hospitalAddress}
              onChange={handleChange}
              className="border border-gray-300 rounded-lg px-4 py-3"
            />

            {/* URGENCY */}
            <select
              name="urgency"
              value={formData.urgency}
              onChange={handleChange}
              className="border border-gray-300 rounded-lg px-4 py-3"
            >
              <option>LOW</option>
              <option>MEDIUM</option>
              <option>HIGH</option>
              <option>CRITICAL</option>
            </select>

            {/* NOTES */}
            <textarea
              name="additionalNotes"
              placeholder="Additional Notes"
              value={formData.additionalNotes}
              onChange={handleChange}
              rows="4"
              className="border border-gray-300 rounded-lg px-4 py-3 md:col-span-2"
            />

            {/* BUTTON */}
            <button
              type="submit"
              disabled={loading}
              className="md:col-span-2 bg-red-600 text-white py-4 rounded-lg font-semibold hover:bg-red-700 transition"
            >
              {loading
                ? "Creating Request..."
                : "Create Emergency Request"}
            </button>

          </form>

        </div>

      </div>
    </div>
  );
}

export default CreateRequestPage;