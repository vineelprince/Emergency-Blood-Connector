import { useEffect, useState } from "react";
import Loader from "../../components/Loader";
import EmptyState from "../../components/EmptyState";
import axiosInstance from "../../api/axios";
import socket from "../../socket";

function AllRequestsPage() {

  const [requests, setRequests] =
    useState([]);

  const [loading, setLoading] =
    useState(true);

  const token =
    localStorage.getItem("token");

  // ================= FETCH =================

  const fetchRequests =
    async () => {

      try {

        const response =
          await axiosInstance.get(
            "/requests",
            {
              headers: {
                Authorization:
                  `Bearer ${token}`,
              },
            }
          );

        setRequests(
          response.data.requests || []
        );

      } catch (error) {

        console.log(error);

      } finally {

        setLoading(false);
      }
    };

  useEffect(() => {

  fetchRequests();

  socket.on(
    "new-request",
    fetchRequests
  );

  socket.on(
    "request-response",
    fetchRequests
  );

  socket.on(
    "request-status-updated",
    fetchRequests
  );

  return () => {

    socket.off(
      "new-request",
      fetchRequests
    );

    socket.off(
      "request-response",
      fetchRequests
    );

    socket.off(
      "request-status-updated",
      fetchRequests
    );
  };

}, []);

  // ================= RESPOND =================

  const handleRespond =
    async (requestId) => {

      try {

        await axiosInstance.post(
          `/requests/${requestId}/respond`,
          {},
          {
            headers: {
              Authorization:
                `Bearer ${token}`,
            },
          }
        );

        alert(
          "Response submitted successfully"
        );

        fetchRequests();

      } catch (error) {

        alert(
          error?.response?.data?.message ||
          "Failed to respond"
        );
      }
    };

  // ================= COLORS =================

  const getUrgencyColor =
    (urgency) => {

      switch (urgency) {

        case "CRITICAL":
          return "bg-red-600 text-white";

        case "HIGH":
          return "bg-orange-500 text-white";

        case "MEDIUM":
          return "bg-yellow-400 text-black";

        default:
          return "bg-green-500 text-white";
      }
    };

  const getStatusColor =
    (status) => {

      switch (status) {

        case "ACCEPTED":
          return "bg-blue-500 text-white";

        case "COMPLETED":
          return "bg-green-600 text-white";

        case "CANCELLED":
          return "bg-gray-500 text-white";

        default:
          return "bg-red-500 text-white";
      }
    };

  return (

    <div className="min-h-screen bg-red-50 p-6">

      <div className="max-w-7xl mx-auto">

        <div className="mb-8">

          <h1 className="text-4xl font-bold text-red-600 mb-2">
            Emergency Requests
          </h1>

          <p className="text-gray-600">
            Track active emergency blood requests.
          </p>

        </div>

        {loading ? (

          <Loader />

        ) : requests.length === 0 ? (

          <EmptyState
            icon="🚨"
            title="No Requests Found"
            description="No active emergency requests available."
          />

        ) : (

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">

            {requests.map((request) => (

              <div
                key={request._id}
                className="bg-white rounded-3xl shadow-lg p-6"
              >

                <div className="flex justify-between mb-4">

                  <span
                    className={`px-3 py-1 rounded-full text-sm font-semibold ${getUrgencyColor(
                      request.urgency
                    )}`}
                  >
                    {request.urgency}
                  </span>

                  <span
                    className={`px-3 py-1 rounded-full text-sm font-semibold ${getStatusColor(
                      request.status
                    )}`}
                  >
                    {request.status}
                  </span>

                </div>

                <h2 className="text-2xl font-bold text-red-600 mb-4">
                  {request.patientName}
                </h2>

                <div className="space-y-2 text-gray-700">

                  <p>
                    Blood Group:
                    {" "}
                    <strong>
                      {request.bloodGroup}
                    </strong>
                  </p>

                  <p>
                    Hospital:
                    {" "}
                    <strong>
                      {request.hospitalName}
                    </strong>
                  </p>

                  <p>
                    Units Required:
                    {" "}
                    <strong>
                      {request.unitsRequired}
                    </strong>
                  </p>

                  <p>
                    Contact:
                    {" "}
                    <strong>
                      {request.contactNumber}
                    </strong>
                  </p>

                  <p>
                    Responses:
                    {" "}
                    <strong>
                      {request.responders?.length || 0}
                    </strong>
                  </p>

                </div>

                {request.additionalNotes && (

                  <div className="mt-4 bg-gray-100 p-3 rounded-lg text-sm">
                    {request.additionalNotes}
                  </div>

                )}

                <div className="grid grid-cols-3 gap-2 mt-6">

                  <button
                    onClick={() =>
                      handleRespond(
                        request._id
                      )
                    }
                    className="bg-red-600 text-white py-2 rounded-xl"
                  >
                    Respond
                  </button>

                  <a
                    href={`tel:${request.contactNumber}`}
                    className="bg-blue-600 text-white text-center py-2 rounded-xl"
                  >
                    Call
                  </a>

                  <a
                    href={`https://wa.me/${request.contactNumber}`}
                    target="_blank"
                    rel="noreferrer"
                    className="bg-green-600 text-white text-center py-2 rounded-xl"
                  >
                    WhatsApp
                  </a>

                </div>

              </div>

            ))}

          </div>

        )}

      </div>

    </div>
  );
}

export default AllRequestsPage;