import { Link } from "react-router-dom";

function NotFoundPage() {
  return (
    <div className="min-h-screen bg-red-50 flex items-center justify-center px-4">

      <div className="bg-white shadow-xl rounded-3xl p-10 max-w-lg text-center">

        {/* ERROR CODE */}
        <h1 className="text-8xl font-bold text-red-600 mb-4">
          404
        </h1>

        {/* TITLE */}
        <h2 className="text-3xl font-bold text-gray-800 mb-4">
          Page Not Found
        </h2>

        {/* DESCRIPTION */}
        <p className="text-gray-600 mb-8">
          The page you are looking for does not exist
          or may have been moved.
        </p>

        {/* BUTTON */}
        <Link
          to="/dashboard"
          className="bg-red-600 text-white px-8 py-4 rounded-xl font-semibold hover:bg-red-700 transition"
        >
          Go To Dashboard
        </Link>

      </div>

    </div>
  );
}

export default NotFoundPage;