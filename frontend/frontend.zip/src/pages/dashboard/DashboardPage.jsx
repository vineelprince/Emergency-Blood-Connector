import { useEffect, useState } from "react";

import { Link } from "react-router-dom";

import axiosInstance from "../../api/axios";

function DashboardPage() {
  const user = JSON.parse(localStorage.getItem("user"));

  // ================= STATES =================

  const [stats, setStats] = useState({
    totalDonors: 0,
    availableDonors: 0,
    totalRequests: 0,
    myRequests: 0,
  });

  const [recentRequests, setRecentRequests] =
    useState([]);

  // ================= FETCH STATS =================

  const fetchStats = async () => {
    try {

      const token =
        localStorage.getItem("token");

      const response =
        await axiosInstance.get(
          "/dashboard/stats",
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );

      setStats(response.data.stats);

    } catch (error) {
      console.log(error);
    }
  };

  // ================= FETCH RECENT REQUESTS =================

  const fetchRecentRequests =
    async () => {
      try {

        const token =
          localStorage.getItem("token");

        const response =
          await axiosInstance.get(
            "/requests/recent",
            {
              headers: {
                Authorization: `Bearer ${token}`,
              },
            }
          );

        setRecentRequests(
          response.data.requests
        );

      } catch (error) {
        console.log(error);
      }
    };

  // ================= USE EFFECT =================

  useEffect(() => {
    fetchStats();
    fetchRecentRequests();
  }, []);

  return (
    <div className="min-h-screen bg-red-50 p-6">

      <div className="max-w-7xl mx-auto">

        {/* HEADER */}
        <div className="bg-white rounded-2xl shadow-md p-6 mb-8">

          <h1 className="text-4xl font-bold text-red-600 mb-2">
            Welcome, {user?.firstName} 👋
          </h1>

          <p className="text-gray-600">
            Manage blood donations and emergency requests.
          </p>

        </div>

        {/* ANALYTICS */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">

          {/* TOTAL DONORS */}
          <div className="bg-white p-6 rounded-2xl shadow-md">

            <h2 className="text-lg font-semibold text-gray-700 mb-2">
              Total Donors
            </h2>

            <p className="text-4xl font-bold text-red-600">
              {stats.totalDonors}
            </p>

          </div>

          {/* AVAILABLE DONORS */}
          <div className="bg-white p-6 rounded-2xl shadow-md">

            <h2 className="text-lg font-semibold text-gray-700 mb-2">
              Available Donors
            </h2>

            <p className="text-4xl font-bold text-green-600">
              {stats.availableDonors}
            </p>

          </div>

          {/* TOTAL REQUESTS */}
          <div className="bg-white p-6 rounded-2xl shadow-md">

            <h2 className="text-lg font-semibold text-gray-700 mb-2">
              Total Requests
            </h2>

            <p className="text-4xl font-bold text-blue-600">
              {stats.totalRequests}
            </p>

          </div>

          {/* MY REQUESTS */}
          <div className="bg-white p-6 rounded-2xl shadow-md">

            <h2 className="text-lg font-semibold text-gray-700 mb-2">
              My Requests
            </h2>

            <p className="text-4xl font-bold text-orange-500">
              {stats.myRequests}
            </p>

          </div>

        </div>

        {/* RECENT EMERGENCIES */}
        <div className="mb-10">

          <h2 className="text-3xl font-bold text-gray-800 mb-6">
            Recent Emergencies 🚨
          </h2>

          {recentRequests.length === 0 ? (

            <div className="bg-white rounded-2xl shadow-md p-6 text-gray-500">
              No emergency requests found
            </div>

          ) : (

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">

              {recentRequests.map((request) => (

                <div
                  key={request._id}
                  className="bg-white rounded-2xl shadow-md p-6 border-l-8 border-red-600"
                >

                  {/* TOP */}
                  <div className="flex items-center justify-between mb-4">

                    <span
                      className={`px-3 py-1 rounded-full text-sm font-semibold ${
                        request.urgency ===
                        "CRITICAL"
                          ? "bg-red-600 text-white"
                          : request.urgency ===
                            "HIGH"
                          ? "bg-orange-500 text-white"
                          : request.urgency ===
                            "MEDIUM"
                          ? "bg-yellow-400 text-black"
                          : "bg-green-500 text-white"
                      }`}
                    >
                      {request.urgency}
                    </span>

                    <span className="text-sm text-gray-500">
                      {request.status}
                    </span>

                  </div>

                  {/* PATIENT */}
                  <h3 className="text-2xl font-bold text-red-600 mb-3">
                    {request.patientName}
                  </h3>

                  {/* DETAILS */}
                  <div className="space-y-2 text-gray-700">

                    <p>
                      🩸 Blood Group:
                      <span className="font-semibold">
                        {" "}
                        {request.bloodGroup}
                      </span>
                    </p>

                    <p>
                      🏥 Hospital:
                      <span className="font-semibold">
                        {" "}
                        {request.hospitalName}
                      </span>
                    </p>

                    <p>
                      📍 Location:
                      <span className="font-semibold">
                        {" "}
                        {request.hospitalAddress}
                      </span>
                    </p>

                  </div>

                </div>
              ))}

            </div>
          )}

        </div>

        {/* QUICK ACTIONS */}
        <div>

          <h2 className="text-3xl font-bold text-gray-800 mb-6">
            Quick Actions ⚡
          </h2>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">

            {/* EMERGENCY SEARCH */}
            <Link
  to="/emergency-alerts"
  className="bg-white rounded-2xl shadow-md p-6 hover:shadow-xl transition"
>

  <h3 className="text-2xl font-bold text-red-600 mb-3">
    🚨 Emergency Alerts
  </h3>

  <p className="text-gray-600">
    Monitor active emergency blood alerts.
  </p>

</Link>
            <Link
              to="/emergency-search"
              className="bg-white rounded-2xl shadow-md p-6 hover:shadow-xl transition"
            >

              <h3 className="text-2xl font-bold text-red-600 mb-3">
                🚨 Emergency Search
              </h3>

              <p className="text-gray-600">
                Search donors, blood banks, and hospitals instantly.
              </p>

            </Link>
            <Link
  to="/analytics"
  className="bg-white rounded-2xl shadow-md p-6 hover:shadow-xl transition"
>

  <h3 className="text-2xl font-bold text-red-600 mb-3">
    📊 Analytics
  </h3>

  <p className="text-gray-600">
    Monitor donor and emergency system analytics.
  </p>

</Link>

            {/* SEARCH DONORS */}
            <Link
              to="/donors"
              className="bg-white rounded-2xl shadow-md p-6 hover:shadow-xl transition"
            >

              <h3 className="text-2xl font-bold text-red-600 mb-3">
                🔍 Search Donors
              </h3>

              <p className="text-gray-600">
                Find blood donors instantly.
              </p>

            </Link>

            {/* CREATE REQUEST */}
            <Link
              to="/create-request"
              className="bg-white rounded-2xl shadow-md p-6 hover:shadow-xl transition"
            >

              <h3 className="text-2xl font-bold text-red-600 mb-3">
                🚨 Create Request
              </h3>

              <p className="text-gray-600">
                Create emergency blood requests.
              </p>

            </Link>

            {/* ALL REQUESTS */}
            <Link
              to="/requests"
              className="bg-white rounded-2xl shadow-md p-6 hover:shadow-xl transition"
            >

              <h3 className="text-2xl font-bold text-red-600 mb-3">
                📋 All Requests
              </h3>

              <p className="text-gray-600">
                View all emergency requests.
              </p>

            </Link>

            {/* MY REQUESTS */}
            <Link
              to="/my-requests"
              className="bg-white rounded-2xl shadow-md p-6 hover:shadow-xl transition"
            >

              <h3 className="text-2xl font-bold text-red-600 mb-3">
                🩸 My Requests
              </h3>

              <p className="text-gray-600">
                Track your emergency requests.
              </p>

            </Link>

          </div>

        </div>

      </div>

    </div>
  );
}

export default DashboardPage;